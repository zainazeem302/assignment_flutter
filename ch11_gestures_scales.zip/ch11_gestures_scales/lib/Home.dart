import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  HomeState createState() => HomeState();
}

class HomeState extends State<Home> {
  // Variables for tracking image position and scaling
  Offset startLastOffset = Offset.zero;
  Offset lastOffset = Offset.zero;
  Offset currentOffset = Offset.zero;
  double lastScale = 1.0;
  double currentScale = 1.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: buildBody(context),
    );
  }

  Widget buildBody(BuildContext context) {
    return GestureDetector(
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          _transformMatrix4(),
          _positionedStatusBar(context),
          _positionedInkWellAndInkResponse(context), // Add the InkWellAndInkResponse widget here
        ],
      ),
      onScaleStart: _onScaleStart,
      onScaleUpdate: _onScaleUpdate,
      onDoubleTap: _onDoubleTap,
      onLongPress: _onLongPress,
    );
  }

  void _onScaleStart(ScaleStartDetails details) {
    setState(() {
      startLastOffset = details.focalPoint;
      lastOffset = currentOffset;
      lastScale = currentScale;
    });
  }

  void _onScaleUpdate(ScaleUpdateDetails details) {
    setState(() {
      currentScale = lastScale * details.scale;
      currentOffset = lastOffset + (details.focalPoint - startLastOffset);
    });
  }

  void _onDoubleTap() {
    setState(() {
      currentScale = 1.0;
      currentOffset = Offset.zero;
    });
  }

  void _onLongPress() {
    // Placeholder for long press action if needed
  }

  Transform _transformMatrix4() {
    return Transform(
      transform: Matrix4.identity()
        ..scale(currentScale, currentScale)
        ..translate(currentOffset.dx, currentOffset.dy),
      alignment: FractionalOffset.center,
      child: Image(
        image: AssetImage('assets/images/pizza.jpg'),
      ),
    );
  }

  Positioned _positionedStatusBar(BuildContext context) {
    return Positioned(
      top: 0.0,
      width: MediaQuery.of(context).size.width,
      child: Container(
        color: Colors.white54,
        height: 50.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Text(
              'Scale: ${currentScale.toStringAsFixed(4)}',
            ),
            Text(
              'Current: (${currentOffset.dx.toStringAsFixed(4)}, ${currentOffset.dy.toStringAsFixed(4)})',
            ),
          ],
        ),
      ),
    );
  }

  Positioned _positionedInkWellAndInkResponse(BuildContext context) {
    return Positioned(
      top: 50.0,
      width: MediaQuery.of(context).size.width,
      child: Container(
        color: Colors.white54,
        height: 56.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            InkWell(
              child: Container(
                height: 48.0,
                width: 128.0,
                color: Colors.black12,
                child: Icon(
                  Icons.touch_app,
                  size: 32.0,
                ),
              ),
              splashColor: Colors.lightGreenAccent,
              highlightColor: Colors.lightBlueAccent,
              onTap: _setScaleSmall,
              onDoubleTap: _setScaleBig,
              onLongPress: _onLongPress,
            ),
            InkResponse(
              child: Container(
                height: 48.0,
                width: 128.0,
                color: Colors.black12,
                child: Icon(
                  Icons.touch_app,
                  size: 32.0,
                ),
              ),
              splashColor: Colors.lightGreenAccent,
              highlightColor: Colors.lightBlueAccent,
              onTap: _setScaleSmall,
              onDoubleTap: _setScaleBig,
              onLongPress: _onLongPress,
            ),
          ],
        ),
      ),
    );
  }

  void _setScaleSmall() {
    setState(() {
      currentScale = 0.5;
    });
  }

  void _setScaleBig() {
    setState(() {
      currentScale = 16.0;
    });
  }
}
