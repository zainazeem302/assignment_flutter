package com.example.ch11_gestures_scales

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
