import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String _gestureDetected = 'No gesture detected';
  Color _paintedColor = Colors.black;

  void _displayGestureDetected(String gesture) {
    setState(() {
      _gestureDetected = gesture;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              _buildGestureDetector(),
              Divider(
                color: Colors.black,
                height: 44.0,
              ),
              _buildDraggable(),
              Divider(
                color: Colors.black,
                height: 44.0,
              ),
              _buildDragTarget(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGestureDetector() {
    return GestureDetector(
      onTap: () {
        print('onTap');
        _displayGestureDetected('onTap');
      },
      onDoubleTap: () {
        print('onDoubleTap');
        _displayGestureDetected('onDoubleTap');
      },
      onLongPress: () {
        print('onLongPress');
        _displayGestureDetected('onLongPress');
      },
      onPanUpdate: (details) {
        print('onPanUpdate: $details');
        _displayGestureDetected('onPanUpdate:\n$details');
      },
      child: Container(
        color: Colors.lightGreen.shade100,
        width: double.infinity,
        padding: EdgeInsets.all(24.0),
        child: Column(
          children: <Widget>[
            Icon(
              Icons.access_alarm,
              size: 98.0,
            ),
            Text(
              '$_gestureDetected',
              style: TextStyle(fontSize: 18.0),
            ),
          ],
        ),
      ),
    );
  }

  Draggable<int> _buildDraggable() {
    return Draggable<int>(
      data: Colors.deepOrange.value,
      child: Column(
        children: <Widget>[
          Icon(
            Icons.palette,
            color: Colors.deepOrange,
            size: 48.0,
          ),
          Text('Drag Me below to change color'),
        ],
      ),
      feedback: Icon(
        Icons.brush,
        color: Colors.deepOrange,
        size: 80.0,
      ),
      childWhenDragging: Icon(
        Icons.palette,
        color: Colors.grey,
        size: 48.0,
      ),
    );
  }

  DragTarget<int> _buildDragTarget() {
    return DragTarget<int>(
      onAccept: (colorValue) {
        setState(() {
          _paintedColor = Color(colorValue);
        });
      },
      builder: (BuildContext context, List<dynamic> acceptedData, List<dynamic> rejectedData) {
        return Container(
          width: 200,
          height: 200,
          color: Colors.white,
          alignment: Alignment.center,
          child: acceptedData.isEmpty
              ? Text(
            'Drag Here to see color change',
            style: TextStyle(color: _paintedColor),
          )
              : Text(
            'Painting Color: ${acceptedData[0]}',
            style: TextStyle(
              color: Color(acceptedData[0]),
              fontWeight: FontWeight.bold,
            ),
          ),
        );
      },
    );
  }
}
