package com.example.ch11_gesture_drag_drop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
